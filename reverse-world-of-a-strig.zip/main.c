/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main()
{
    int i,j,l,start,end;
    char str[100];
   scanf("%[^\n]s",str);
   
    l=strlen(str);
    end=l-1;
    for(i=(l-1); i>=0; i--){
        if(str[i]==' '|| i==0){
           if(i==0)
           start=0;
           else
           start=i+1;
           for(j=start; j<=end; j++){
               printf("%c",str[j]);
           }
           end=i-1;
           printf(" ");
           
        }
        
    }
    

    return 0;
}
