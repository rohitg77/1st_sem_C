/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,m,i,j,s;
    scanf("%d\n%d",&n,&m);
    int ar[n][n];
    for(i=0; i<n; i++){
        for(j=0; j<m; j++){
            scanf("%d",&ar[i][j]);
        }
    }
    for(i=0; i<n; i++){
        for(j=0; j<m; j++){
            printf("%d",ar[i][j]);
        }
        printf("\n");
    }
    

 for(i=0; i<n; i++){
        for(j=0; j<m; j++){
            if(i==j){
                s=ar[i][j];
                ar[i][j]=ar[i][n-i-1];
                ar[i][n-i-1]=s;
                
        

            }

            
        }
        
    }
    for(i=0; i<n; i++){
        for(j=0; j<m; j++){
            printf("%d",ar[i][j]);
        }
        printf("\n");
    }

    return 0;
}


