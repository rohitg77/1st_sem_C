/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    
int a=7;
int*ptra=&a;

printf("the adress of a is %p\n",ptra);
printf("the value of a is %d\n",a);
printf("the value of a is %d\n",*ptra);
printf("the adress of ptra is %p",&ptra);

    return 0;
}
