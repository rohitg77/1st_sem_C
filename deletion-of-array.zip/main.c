/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int m,n,i,posi;
    printf("entre number of element in an array\n");
    scanf("%d",&m);
    int ar[m];
    printf("number of elemeny you want to entre in array");
    scanf("%d",&n);
    for(i=0; i<n; i++){
        scanf("%d",&ar[i]);
    }
    
    printf("entre the  position");
    scanf("%d",&posi);
    for(i=posi; i<(n-1); i++){
       ar[i]=ar[i+1];
       
       
    }
    
    n--;
    for(i=0; i<n; i++)
    printf("%d",ar[i]);

    return 0;
}
