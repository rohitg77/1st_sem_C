/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     int a,b,i;
    scanf("%d",&a);
    int po[a];
    for(i=0; i<a; i++){
        scanf("%d",&po[i]);
        //printf("%d",po[i]);
        
        
    }
    for(i=0; i<a/2; i++){
        b=po[i];
        po[i]=po[(a-1)-i];
        po[(a-1)-i]=b;
        
    }
    
    for(i=0; i<a; i++){
       printf("%d",po[i]);
    }
    

    return 0;
}
