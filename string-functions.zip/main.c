/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main()
{
    char a[]="rohit";
    char b[]="priyanka";
    char c[89];
 //  printf("%s",strcat(a,b));
//  puts(strcat(a,b));
  //printf("%d",strlen(a));
  //printf("%s",strrev(a));
 //puts(strrev(a));
 strcpy(c,strcat(a,b));
 puts(c);
 strcmp();
    return 0;
}
