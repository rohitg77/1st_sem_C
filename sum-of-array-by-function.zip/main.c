/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int sum(int p[],int a){
    int i,s=0;
    for(i=0; i<a; i++){
    s=s+p[i];
        
    }
    return s;
}

int main()
{
    int ar[6],i,s;
    for(i=0; i<6; i++)
    scanf("%d",&ar[i]);
    s=sum(ar,6);
    printf("%d",s);

    return 0;
}
