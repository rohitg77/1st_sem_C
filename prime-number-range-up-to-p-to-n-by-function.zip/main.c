/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void cprime(int p,int q){
    int i,j,f;
    
    for(int i=p; i<=q; i++ ){
        f=0;
        for(j=2; j<i; j++){
            if(i%j==0){
                f=1;
                break;
            }
        }
        if(f==0){
        printf("%d, ",i);
        
    }
    
    
    }
    
    
}
int main()
{
    int n,m;
    scanf("%d%d",&n,&m);
    cprime(n,m);

    return 0;
}
