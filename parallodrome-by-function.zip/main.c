#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int parallo(int n) {
    int a,b=0;
    
    
    while(n>0){
        a=n%10;
        b=(b*10)+a;
        n=n/10;
        
        
    }
    return b;
    
}
    
        int main(){
            int n,k;
            printf("entre the number");
            scanf("%d",&n);
            k=parallo(n);
            if(n==k)
        printf("Palindrome.");
    
    else
        printf("Not Palindrome.");

            
            return 0;
        }
        

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    

