/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int strong(int n)
{
    int r,i,b=0,a=1;
    int s=n;
    while(s>0){
        r=s%10;
        for(i=1; i<=r; i++)
        a=a*i;
        b=b+a;
        s=s/10;
        a=1;
    }
    if(b==n)
    return 1;
    else
    return 0;
    

    
}
void main(){
    int a,b,n;
    printf("entre the number");
    scanf("%d%d",&a,&b);
    for(n=a; n<=b; n++){
        int ans=strong(n);
        if(ans==1)
        printf("%d\n",n);
    }
    

   
}
