#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
int armstrong(int n){
    int l,r;
    int s = n;
    int b = 0;
    l=(log10(n)+1);
    while(s>0){
        r=s%10;
        b=(b+pow(r,l));
        s=s/10;
        
        
        
    }
      if(n==b){
          return 1;
      }
         else{
         return 0;
         }
}
    


void main(){
    int p,q;
    scanf("%d%d",&p,&q);
    for(int n=p;n<=q;n++){
    int ans = armstrong(n);
    if(ans == 1) printf("%d",n);
    }
    
}
    

