/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[10];
    int b=0,c,d=0,e;
    for(int i=0; i<10; i++){
        scanf("%d",&a[i]);
    }
    for(int i=0; i<10; i++){
        if(a[i]>0)
        c=++b;
        if(a[i]<0)
        e=++d;
    }
    printf("%d\n%d",c,e);
    

    return 0;
}

