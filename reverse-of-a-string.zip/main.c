/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main()
{
    char str[100];
    int l,tempt;
    scanf("%[^\n]s",str);
    l=strlen(str);
    for(int i=0; i<l/2; i++){
        tempt=str[i];
        str[i]=str[l-i-1];
        str[l-i-1]=tempt;
    }
    printf("%s",str);

    return 0;
}
