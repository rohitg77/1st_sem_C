/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int power(int p,int q){
    int n=1;
    while(q>0){
    n=n*p;
    q--;
    
    }
    return n;
    
}

int main()
{       int a,b,s;
scanf("%d%d",&a,&b);

    s=power(a,b);
    printf("%d",s);

    return 0;
}
