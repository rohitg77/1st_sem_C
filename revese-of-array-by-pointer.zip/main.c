/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void arpr(int p[],int n){
    int i;
    
    for(i=(n-1); i>=0; i--){
        
        printf("%d",p[i]);
        
    }
    
}

int main()
{
    int n,i;
    scanf("%d",&n);
    int ar[n];
    for(i=0; i<n; i++)
    scanf("%d",&ar[i]);
    arpr(ar,n);

    return 0;
}


