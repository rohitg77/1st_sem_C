/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,m,i,j;
    scanf("%d\n%d",&n,&m);
    int *p=&n;
    int *q=&m;
    int ar[n][m];
    for(i=0; i<*p; i++){
        for(j=0; j<*q; j++){
            scanf("%d",&ar[i][j]);
        }
    }
    int arr[n][m];
 for(i=0; i<*p; i++){
        for(j=0; j<*q; j++){
            scanf("%d",&arr[i][j]);
        }
        
    }
    int arrr[n][m];
     for(i=0; i<*p; i++){
        for(j=0; j<*q; j++){
            arrr[i][j]=(ar[i][j]+arr[i][j]);
        }
        
    }
for(i=0; i<*p; i++){
        for(j=0; j<*q; j++){
            printf("%d",arrr[i][j]);
        
        }
        printf("\n");
        
    }

    return 0;
}

