#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int arm(int n) {
int l,r,b=0;
    
    
    l=(log10(n)+1);
    while(n>0){
        r=n%10;
        b=(b+pow(r,l));
        n=n/10;
    }
        
        return b;
        
    
      
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    
}
int main()
{int n,s;
    printf("entre the number");
   scanf("%d",&n);
   s=arm(n);
   if(n==s)
          printf("Armstrong Number.");
    else
        printf("Not Armstrong.");
        return 0;
}