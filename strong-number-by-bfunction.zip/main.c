/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int strong(int n)
{
    int r,i,b=0,a=1;
    while(n>0){
        r=n%10;
        for(i=1; i<=r; i++)
        a=a*i;
        b=b+a;
        n=n/10;
        a=1;
    }

    return b;
}
int main(){
    int n,s;
    printf("entre the number");
    scanf("%d",&n);
    
   s=strong(n);
   if(n==s)
   printf("strong number");
   else 
   printf("not strong number");
   return 0;
}