/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,m,i,j,f=0;
    scanf("%d\n%d",&n,&m);
    int ar[n][m];
    for(i=0; i<n; i++){
        for(j=0; j<m; j++){
            scanf("%d",&ar[i][j]);
        }
    }
 for(i=0; i<n; i++){
        for(j=0; j<m; j++){
            printf("%d",ar[i][j]);
        }
        printf("\n");
    }
    for(i=0; i<n; i++){
        for(j=0; j<m; j++){
            if(i>j){
                if(ar[i][j]!=0){
                    f=1;
                    break;
                }
            }
        }
    }
            if(f==1)
            printf("it is not upper triangular matrix");
            else 
            printf("upper triangular matrix");
                
            
            
    

    return 0;
}
