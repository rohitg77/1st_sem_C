/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int perfectnumber(int n)
{
    int a=0;
    int s=n;
    
    
    for(int i=1; i<s; i++){
        if(s%i==0){
            a=a+i;
        }
        
    }
    if(n==a)
    return 1;
    else 
    return 0;
}
int main()
{
    int p,n;
    int q,ans;
    scanf("%d%d",&p,&q);
    for(n=p; n<=q; n++){
     ans=perfectnumber(n);   
    
    if(ans==1)
    printf("%d\n",n);
    }
}

