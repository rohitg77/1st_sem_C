/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>


int main()
{
    char s[100],ch,m;
    int i,f=0;
    
    gets(s);
    
    printf("entre character you want to entre");
    
    scanf("%c",&ch);
    
    for(i=0; i<=strlen(s); i++){
        if(s[i]==ch){
        f=1;
        break;}
        
    }
    if(f==1){
    printf("element %c is at a position %d",ch,i+1);
    }
    else
    printf("\nelement ot found");
    
    
    
    
    
    

    return 0;
}

