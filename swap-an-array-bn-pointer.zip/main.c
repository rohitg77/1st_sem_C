/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void arpr(int p[],int n,int q[]){
    int t,i;
    
    for(i=0; i<n; i++){
        t=p[i];
        p[i]=q[i];
        q[i]=t;
      
             
    }
    for(i=0; i<n; i++)
    printf("first array%d\n",p[i]);
    for(i=0; i<n; i++)
    printf("second array%d\n",q[i]);
            

    
}

int main()
{
    int n,m,i;
    scanf("%d",&n);
    int ar[n];
    for(i=0; i<n; i++)
    scanf("%d",&ar[i]);
    int arr[n];
    for(i=0; i<n; i++)
    scanf("%d",&arr[i]);
    arpr(ar,n,arr);

    return 0;
}


