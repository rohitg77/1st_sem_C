/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main()
{
    char str[100];
    char str1[100];
    int l,f=0,tempt;
    
    scanf("%[^\n]s",str);
    for(int i=0; str[i]; i++){
        str1[i]=str[i];
    }
    
    l=strlen(str);
    for(int i=0; i<l/2; i++){
        tempt=str[i];
        str[i]=str[l-i-1];
        str[l-i-1]=tempt;
    }
    for(int i=0; str[i]; i++){
        if(str1[i]!=str[i])
        f=1;
        break;
    }
    if(f==1)
    printf(" not parralodrome");
    else 
    printf("parralodrome");
    

    return 0;
}
