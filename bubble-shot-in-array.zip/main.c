/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,i,j,t;
    printf("entre the value of n");
    scanf("%d",&n);
    int ar[n];
    for(i=0; i<n; i++)
    scanf("%d",&ar[i]);
    for(j=0; j<n-1; j++){
       for(i=0; i<n-1-j; i++){
           if(ar[i]>ar[i+1]){
               t=ar[i];
               ar[i]=ar[i+1];
               ar[i+1]=t;
           }
       } 
    }
    for(i=0; i<n; i++){
        printf("%d ",ar[i]);
    }
    
    return 0;
}
