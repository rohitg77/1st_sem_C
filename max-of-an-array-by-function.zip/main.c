/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int armax(int ar[],int n){
    int s,i;
    s=ar[0];
    for(i=1; i<n; i++){
        if(ar[i]>s)
        s=ar[i];
    }
    return s;
    
    
}

int main()
{
    int n,i,s;
    scanf("%d",&n);
    int ar[n];
    for(i=0; i<n; i++)
    scanf("%d",&ar[i]);
    s=armax(ar,n);
    printf("maximum element of an array%d",s);

    return 0;
}
