/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,i,ele,k,f=0;
    printf("entre the value of a\n");
    scanf("%d",&a);
    int *p=&a;
    int ar[*p];
    for(i=0; i<*p; i++){
        scanf("%d",&ar[i]);
    }
    printf("entre the element\n");
    scanf("%d",&ele);
    for(i=0; i<*p; i++){
        if(ar[i]==ele){
           f=1;
        k=i+1;
        break;
        
    }
    }
    if(f==1)
    printf("the posi of element %d",k);
    else
    printf("element not found");

    return 0;
}

