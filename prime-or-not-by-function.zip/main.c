/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int prime(int n){
    int i,f;
    for(i=2; i<n; i++){
        if(n%i==0)
        f=1;
    break;
    }
    return f;
}

int main()
{
    int n,f;
    scanf("%d",&n);
    f=prime(n);
if(f==1)
printf("not prime");
else
printf("prime");
    return 0;
}
