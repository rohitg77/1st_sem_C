/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int perfect(int n)
{
    int i,a=0;
    for(i=1; i<n; i++){
        if(n%i==0)
        a=a+i;
    }
    
    

    return a;
}
int main(){
    int n,s;
    printf("entre the number");
    scanf("%d",&n);
    s=perfect(n);
    if(n==s)
    printf("perfect number");
    else
    printf("not perfect");
}