/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{int i,j;
    char s[100];
    char c[100];
    char d[200];
    
    scanf("%s",s);
    scanf("%s",c);
    for(i=0; s[i]; i++){
        d[i]=s[i];
    }
    for(j=0; c[j]; j++,i++){
        d[i]=c[j];
    }
    d[i]=0;
    printf("%s",d);

    return 0;
}

