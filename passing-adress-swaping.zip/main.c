/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void swap(int *p,int *q){
    int t;
    t=*p;
    *p=*q;
    *q=t;
}


int main()
{
    int a,b;
    scanf("%d%d",&a,&b);
    printf("before values %d,%d",a,b);
    swap(&a,&b);
    printf("\n%d%d",a,b);

    return 0;
}
