/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,i;
    scanf("%d %d",&a,&b);
    for(i=a; i<=b; i++){
        if(i<10){
            if(i==1)
            printf("one\n");
            else if(i==2)
            printf("two\n");
            else if(i==3)
            printf("three\n");
            else if(i==4)
            printf("four\n");
            else if(i==5)
            printf("five\n");
            else if(i==6)
            printf("six\n");
            else if(i==7)
            printf("seven\n");
            else if(i==8)
            printf("eight\n");
            else
            printf("nine\n");
            
            
            
            }
            else
            {
               if(i%2==0)
               printf("even\n");
               else
               printf("odd\n");
               
            }
            
        }
    
    

    return 0;
}
