/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,i,j=0,c;
    printf("entre no of elements of first and second array\n");
    scanf("%d%d",&a,&b);
    int ar[a];
    for(i=0; i<a; i++){
        scanf("%d",&ar[i]);
    }
    int arr[b];
    for(i=0; i<b; i++){
        scanf("%d",&arr[i]);
    }
    c=a+b;
    int arrr[c];
    for(i=0; i<a; i++){
        arrr[i]=ar[i];
    }
    for(i=a; i<c; i++){
        arrr[i]=arr[j];
        j++;
    }
    for(i=0; i<c; i++){
        printf("%d,",arrr[i]);
        
    }
    
    

    return 0;
}
