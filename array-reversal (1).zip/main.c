/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
        int a[]={1,3,4,5,6};
        int b;
        for(int i=0; i<5/2; i++){
            b=a[i];
            a[i]=a[4-i];
            a[4-i]=b;
            
        }
        for(int i=0; i<5; i++){
            printf("%d",a[i]);
            
        }

    return 0;
}
